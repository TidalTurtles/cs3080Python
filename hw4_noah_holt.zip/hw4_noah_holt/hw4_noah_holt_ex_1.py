'''
Homework 4
Exercise 1
Noah Holt
Due: 29 oct 2022
Rectangle, Circle, Square
    make 3 classes for each shape
        each should have methods for:
            area,
            diagonal of rec/square
            perimeter
'''
import math
'''
Rectangle class
    Methods:
        area = Length * Width
        diagonal = ((length)^2 + (width)^2)^(1/2) (ie pythagorus)
        perimeter = 2length + 2 width
'''
class Rectangle:
    def __init__(self, width, length):
        self.width = width
        self.length = length

    def area(self):
        area = self.length * self.width
        return area

    def perimeter(self):
        perimeter = (2*self.width) + (2*self.length)
        return perimeter

    def diagonal(self):
        diagonal = math.sqrt((self.length ** 2) + (self.width ** 2))
        return diagonal


'''
Square Class
    Methods
        area = length^2
        diagonal = (area + area)^(1/2)
        perimeter = 4length
'''
class Square:
    def __init__(self, length):
        self.length = length

    def area(self):
        area = self.length**2
        return area

    def perimeter(self):
        perimeter = 4 * self.length
        return perimeter

    def diagonal(self):
        diagonal = math.sqrt((self.length ** 2) + (self.length ** 2))
        return diagonal

'''
Circle Class
    Methods
        area = pi * radius^2
        perimeter = 2 * pi * radius
'''
class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        area = math.pi * (self.radius ** 2)
        return area

    def perimeter(self):
        perimeter = 2 * math.pi * self.radius
        return perimeter


# testing outputs
shape1 = Square(3)
print("Square of length 3 area perimeter and diagonal")
print(shape1.area())
print(shape1.perimeter())
print(shape1.diagonal())
print()
shape2 = Rectangle(3, 4)
print("Rectangle of length 3 and width 4 area perimeter and diagonal")
print(shape2.area())
print(shape2.perimeter())
print(shape2.diagonal())
print()
shape3 = Circle(3)
print("Circle of radius 3 area perimeter")
print(shape1.area())
print(shape1.perimeter())
print()
