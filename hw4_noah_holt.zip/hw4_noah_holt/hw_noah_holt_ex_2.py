'''
Homework 4
Exercise 2
Noah Holt
Due: 29 oct 2022
Phone number and email extractor
    get text from clipboard
    find phone and email
    print all matches to screen
'''

import re
import pyperclip

# phone number: xxx-xxx-xxxx
# email: ********@****.xxx

textSearch = str(pyperclip.paste())
numMatches = []
mailMatches = []

phoneNumbersRegex = re.compile(r'\d{3}-\d{3}-\d{4}')
for match in phoneNumbersRegex.findall(textSearch):  # add something here
    numMatches += match.group()

emailRegex = re.compile(r'([a-zA-Z0-9._%+-]@[a-zA-Z.-]+(\.[a-zA-Z]{2,4}))')
for found in emailRegex.findall(textSearch):  # add something here
    mailMatches += found.group()

print(numMatches)
print(mailMatches)
