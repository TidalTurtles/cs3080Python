'''
Homework 4
Exercise 3
Noah Holt
Due: 29 oct 2022
Strong Password Check
    takes string
    min length = 8
    upper and lower case
    min one number
    (assume no punctuation or special chars)
    (use regex only)
'''

import re

passWordregex = re.compile(r'(\w)*\d(\w)*')  #\d+ is min 1 number, \w is any value,

userPassword = input("Enter your Password: ")

if len(userPassword) >= 8:
    checking = passWordregex.match(userPassword)
    if checking is not None:
        print("Thats a pretty good Password")
    else:
        print("That password is bad")

else:
    print("That password is bad")




