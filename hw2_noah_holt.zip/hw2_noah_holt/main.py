# Homework_2
# Noah_Holt
# Due: 23 sept 2022
# Collartz Program
#   Part 1: make collartz function
#       call until returns 1
#
#   Part 2: Add try catch to find non int inputs
#       new file though? maybe do it in the collartz I guess then
#
#   Part 3: make list of strings
#       manipulate and print in different ways.
#

#import hw2_noah_holt_ex_1
#import hw2_noah_holt_ex_2
import hw2_noah_holt_ex_3
#import hw2_noah_holt_ex_4
#import hw2_noah_holt_ex_4_2
#import hw2_noah_holt_ex_4_3

#hw2_noah_holt_ex_1
#hw2_noah_holt_ex_2
#hw2_noah_holt_ex_3
#hw2_noah_holt_ex_4
